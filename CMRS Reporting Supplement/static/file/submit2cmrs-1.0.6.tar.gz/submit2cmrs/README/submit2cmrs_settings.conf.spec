[general]
acasDelta = 
c2cReportPath = 
iseSerial = 
iseVersion = 
publisherName = 
publisherVersion = 
reportingBatchSize = 

[online_submission]
certFile = 
keyFile = 
pkiTrust = 
soapEndpoint = 

[proxy]
proxyEnabled = 
proxyPassword = 
proxyUrl = 
proxyUsername = 

[offline_submission]
offlineOutputDirectory = 
offlineReport = 
offlineReportBackupCount = 
offlineUpload = 

[coams_configuration]
reportingAdminOrg = 
reportingCcsafa = 
reportingCndsp = 
reportingCocomaor = 
reportingGeolocation = 
reportingOperationalaccreditation = 
reportingOwnOrg = 

[logging]
loglevel = 

[advanced]
batches_to_inspect = 
c2cAdminorgRule = 
c2cCcsafaRule = 
c2cCndspRule = 
c2cCocomaorRule = 
c2cEndpointAppWlRule = 
c2cEndpointEncryptRule = 
c2cEndpointMalwareRule = 
c2cEndpointMonitorRule = 
c2cFirewallRule = 
c2cGeolocationRule = 
c2cOperationalaccreditationRule = 
c2cOwnorgRule = 
c2cPatchAgentRule = 
c2cPatchingRule = 
c2cPkiRootsRule = 
cmrs_max_retries = 
cmrs_submission_debug = 
logBackupCount = 
logMaxBytes = 
maxConcurrentProcesses = 
