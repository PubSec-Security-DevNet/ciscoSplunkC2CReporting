[submit2cmrs://<name>]
index = (Default: default)
interval = Time interval of the data input, in seconds. (Default: 86400)
