(function () {
    var TAB_ID = "online_submissionTab";
    var TAB_FALLBACK_SELECTORS = [
        "#online_submissionTab",
        "#online_submission",
        "[data-name='online_submission']",
        "[id*='online_submission']",
    ];
    var BUTTON_ID = "cmrs-test-connection-btn";
    var RESULT_ID = "cmrs-test-connection-result";
    var WARNING_ID = "cmrs-test-connection-warning";
    var SAVE_TRIGGER_TEST_DELAY_MS = 1200;

    var state = {
        running: false,
    };

    function currentLocalePrefix() {
        var parts = window.location.pathname.split("/").filter(Boolean);
        if (!parts.length) {
            return "";
        }
        return parts[0].includes("-") ? "/" + parts[0] : "";
    }

    function validationEndpointUrl() {
        return (
            currentLocalePrefix() +
            "/splunkd/__raw/servicesNS/nobody/submit2cmrs/submit2cmrs_settings/test_connection_result?output_mode=json"
        );
    }

    function createStatusPanel() {
        var panel = document.createElement("div");
        panel.id = RESULT_ID;
        panel.style.marginTop = "10px";
        panel.style.padding = "10px";
        panel.style.borderRadius = "4px";
        panel.style.border = "1px solid #c9c9c9";
        panel.style.background = "#f7f7f7";
        panel.style.whiteSpace = "pre-wrap";
        panel.style.fontFamily = "Menlo, Consolas, monospace";
        panel.style.fontSize = "12px";
        panel.textContent = "Run Test Connection to validate mTLS connection to the SOAP endpoint.";
        return panel;
    }

    function extractValidationResponse(payload) {
        var content = payload && payload.entry && payload.entry[0] && payload.entry[0].content;
        if (!content) {
            return {
                status: "FAIL",
                summary: "Validation endpoint returned no content.",
                details: "",
            };
        }

        var handlerPathHit = String(content.handlerPathHit || "").toLowerCase() === "true";
        if (!handlerPathHit) {
            return {
                status: "FAIL",
                summary: "Validation handler path was not executed.",
                details:
                    "Expected handlerPathHit=true but did not receive it.\n\n" +
                    "handlerRawStanzaId=" + String(content.handlerRawStanzaId || "<missing>") + "\n" +
                    "handlerNormalizedStanzaId=" + String(content.handlerNormalizedStanzaId || "<missing>") + "\n\n" +
                    "Raw payload:\n" + JSON.stringify(payload, null, 2),
            };
        }

        return {
            status: String(content.validationStatus || "FAIL"),
            summary: String(content.validationSummary || "Validation finished without summary."),
            details: String(content.validationDetails || ""),
        };
    }

    function setPanelState(panel, state, text) {
        if (state === "PASS") {
            panel.style.borderColor = "#3c763d";
            panel.style.background = "#edf7ed";
            panel.style.color = "#2f5d31";
        } else if (state === "FAIL") {
            panel.style.borderColor = "#a94442";
            panel.style.background = "#fdf0ef";
            panel.style.color = "#8a2f2f";
        } else {
            panel.style.borderColor = "#c9c9c9";
            panel.style.background = "#f7f7f7";
            panel.style.color = "#333";
        }
        panel.textContent = text;
    }

    function updateButtonAvailability(button, warning) {
        button.disabled = state.running;
        button.style.opacity = button.disabled ? "0.65" : "1";
        button.style.cursor = button.disabled ? "not-allowed" : "pointer";
        warning.textContent = "";
    }

    function normalizeToken(value) {
        return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    }

    function readNodeValue(node) {
        if (!node) {
            return "";
        }
        if (typeof node.value === "string") {
            return node.value.trim();
        }
        var text = node.textContent || "";
        return text.trim();
    }

    function matchesFieldNode(node, tokens) {
        var haystack = [
            node.id,
            node.name,
            node.getAttribute && node.getAttribute("data-name"),
            node.getAttribute && node.getAttribute("aria-label"),
            node.getAttribute && node.getAttribute("placeholder"),
            node.getAttribute && node.getAttribute("for"),
        ]
            .join(" ")
            .toLowerCase();

        for (var i = 0; i < tokens.length; i++) {
            if (haystack.indexOf(tokens[i]) !== -1) {
                return true;
            }
        }
        return false;
    }

    function findFieldValue(tab, fieldName, aliases) {
        if (!tab) {
            return "";
        }

        var allTokens = [fieldName].concat(aliases || []);
        var normalizedTokens = [];
        for (var t = 0; t < allTokens.length; t++) {
            normalizedTokens.push(normalizeToken(allTokens[t]));
        }

        var selectors = [
            "[name='" + fieldName + "']",
            "#" + fieldName,
            "[data-name='" + fieldName + "']",
            "[id$='" + fieldName + "']",
            "[id*='" + fieldName + "']",
            "[name*='" + fieldName + "']",
        ];

        for (var i = 0; i < selectors.length; i++) {
            var directNode = tab.querySelector(selectors[i]);
            var directVal = readNodeValue(directNode);
            if (directVal) {
                return directVal;
            }
        }

        var controls = tab.querySelectorAll("input, textarea, select");
        var firstMatchingEmpty = "";
        for (var j = 0; j < controls.length; j++) {
            var control = controls[j];
            if (matchesFieldNode(control, normalizedTokens)) {
                var val = readNodeValue(control);
                if (val) {
                    return val;
                }
                if (!firstMatchingEmpty) {
                    firstMatchingEmpty = "";
                }
            }
        }

        var labels = tab.querySelectorAll("label");
        for (var k = 0; k < labels.length; k++) {
            var label = labels[k];
            var labelToken = normalizeToken(label.textContent || "");
            var isMatch = false;
            for (var m = 0; m < normalizedTokens.length; m++) {
                if (labelToken.indexOf(normalizedTokens[m]) !== -1) {
                    isMatch = true;
                    break;
                }
            }
            if (!isMatch) {
                continue;
            }

            var forId = label.getAttribute("for");
            if (forId) {
                var byFor = tab.querySelector("#" + forId);
                var byForValue = readNodeValue(byFor);
                if (byForValue) {
                    return byForValue;
                }
            }

            var container = label.closest("div, td, th, li, section") || label.parentElement;
            if (container) {
                var siblingField = container.querySelector("input, textarea, select");
                var siblingValue = readNodeValue(siblingField);
                if (siblingValue) {
                    return siblingValue;
                }
            }
        }

        return firstMatchingEmpty;
    }

    function looksLikeCertMaterial(value) {
        if (!value) {
            return false;
        }
        return (
            value.indexOf("-----BEGIN") !== -1 ||
            /[\\/]/.test(value) ||
            /\.(pem|crt|cer|key|p12|pfx|bundle)$/i.test(value)
        );
    }

    function detectValueKind(value) {
        if (!value) {
            return "empty";
        }
        if (value.indexOf("-----BEGIN") !== -1) {
            return "inline-pem";
        }
        if (/[\\/]/.test(value) || /\.[a-z0-9]+$/i.test(value)) {
            return "path-like";
        }
        return "unknown";
    }

    function getEndpointDiagnostics(endpoint) {
        var output = {
            valid: false,
            isHttps: false,
            scheme: "",
            host: "",
            path: "",
            parseError: "",
        };
        if (!endpoint) {
            return output;
        }
        try {
            var parsed = new URL(endpoint);
            output.valid = true;
            output.scheme = parsed.protocol;
            output.host = parsed.host;
            output.path = parsed.pathname || "/";
            output.isHttps = parsed.protocol === "https:";
        } catch (err) {
            output.parseError = err && err.message ? String(err.message) : "invalid URL";
        }
        return output;
    }

    function findOnlineSubmissionTab() {
        var tab = document.getElementById(TAB_ID);
        if (tab) {
            return tab;
        }

        for (var i = 0; i < TAB_FALLBACK_SELECTORS.length; i++) {
            var candidate = document.querySelector(TAB_FALLBACK_SELECTORS[i]);
            if (candidate) {
                return candidate;
            }
        }

        return null;
    }

    async function loadSavedOnlineSubmission() {
        var response = await fetch(savedConfigUrl(), {
            method: "GET",
            credentials: "include",
            headers: {
                Accept: "application/json",
            },
        });

        if (!response.ok) {
            var errorBody = await response.text();
            throw new Error(
                "Saved config request failed with HTTP " + response.status + ".\n" + errorBody
            );
        }

        var payload = await response.json();
        var content = payload && payload.entry && payload.entry[0] && payload.entry[0].content;
        if (!content) {
            throw new Error("Saved config response did not include entry[0].content.");
        }

        return {
            soapEndpoint: String(content.soapEndpoint || "").trim(),
            certFile: String(content.certFile || "").trim(),
            keyFile: String(content.keyFile || "").trim(),
            pkiTrust: String(content.pkiTrust || "").trim(),
        };
    }

    function runClientValidation(values, options) {
        var source = options && options.source ? options.source : "unknown";
        var fetchError = options && options.fetchError ? options.fetchError : "";

        var tab = findOnlineSubmissionTab();
        if (!tab) {
            return {
                status: "FAIL",
                summary: "Online Submission tab is not available.",
                details: "",
            };
        }

        var endpoint = String(values.soapEndpoint || "").trim();
        var cert = String(values.certFile || "").trim();
        var key = String(values.keyFile || "").trim();
        var trust = String(values.pkiTrust || "").trim();
        var endpointInfo = getEndpointDiagnostics(endpoint);
        var certKind = detectValueKind(cert);
        var keyKind = detectValueKind(key);
        var trustKind = detectValueKind(trust);

        var failures = [];
        var warnings = [];

        if (!endpoint) failures.push("soapEndpoint is required.");
        if (!cert) failures.push("certFile is required.");
        if (!key) failures.push("keyFile is required.");
        if (!trust) failures.push("pkiTrust is required.");

        if (endpoint) {
            if (!endpointInfo.valid) {
                failures.push("soapEndpoint is not a valid URL.");
            } else if (!endpointInfo.isHttps) {
                failures.push("soapEndpoint must use https.");
            }
        }

        if (cert && !looksLikeCertMaterial(cert)) {
            warnings.push("certFile does not look like a file path or PEM content.");
        }
        if (key && !looksLikeCertMaterial(key)) {
            warnings.push("keyFile does not look like a file path or PEM content.");
        }
        if (trust && !looksLikeCertMaterial(trust)) {
            warnings.push("pkiTrust does not look like a file path or PEM content.");
        }

        if (fetchError) {
            warnings.push("Saved config read failed; used form fallback. Reason: " + fetchError);
        }

        var status = failures.length ? "FAIL" : "PASS";
        var summary = failures.length
            ? failures[0]
            : "Client-side checks passed for required fields and mTLS value format.";

        var lines = [];
        if (status === "PASS") {
            lines.push("Config Source: " + source);
            lines.push("Endpoint: " + endpointInfo.host);
            lines.push("Timestamp: " + new Date().toISOString());
        } else {
            lines.push("Validation Mode: Browser-side checks against Splunk saved config");
            lines.push("Config Source: " + source);
            lines.push("Network Calls: 1 (saved config read)");
            lines.push("Timestamp: " + new Date().toISOString());
            lines.push("");
            lines.push("Input Snapshot:");
            lines.push("- soapEndpoint: " + (endpoint || "<empty>"));
            lines.push("- certFile: " + (cert ? "<provided>" : "<empty>") + " (kind=" + certKind + ")");
            lines.push("- keyFile: " + (key ? "<provided>" : "<empty>") + " (kind=" + keyKind + ")");
            lines.push("- pkiTrust: " + (trust ? "<provided>" : "<empty>") + " (kind=" + trustKind + ")");
            lines.push("");
            lines.push("Check Results:");
            lines.push("- requiredFields: " + (endpoint && cert && key && trust ? "PASS" : "FAIL"));
            if (!endpoint) {
                lines.push("  [FAIL] soapEndpoint missing");
            }
            if (!cert) {
                lines.push("  [FAIL] certFile missing");
            }
            if (!key) {
                lines.push("  [FAIL] keyFile missing");
            }
            if (!trust) {
                lines.push("  [FAIL] pkiTrust missing");
            }
            lines.push("- endpointParse: " + (endpoint ? (endpointInfo.valid ? "PASS" : "FAIL") : "SKIP"));
            if (endpoint) {
                if (endpointInfo.valid) {
                    lines.push("  scheme=" + endpointInfo.scheme + ", host=" + endpointInfo.host + ", path=" + endpointInfo.path);
                    lines.push("- endpointHttps: " + (endpointInfo.isHttps ? "PASS" : "FAIL"));
                } else {
                    lines.push("  [FAIL] parseError=" + endpointInfo.parseError);
                }
            }
            lines.push("- certFormatHeuristic: " + (cert ? (looksLikeCertMaterial(cert) ? "PASS" : "WARN") : "SKIP"));
            lines.push("- keyFormatHeuristic: " + (key ? (looksLikeCertMaterial(key) ? "PASS" : "WARN") : "SKIP"));
            lines.push("- trustFormatHeuristic: " + (trust ? (looksLikeCertMaterial(trust) ? "PASS" : "WARN") : "SKIP"));

            for (var f = 0; f < failures.length; f++) {
                lines.push("[FAIL] " + failures[f]);
            }
            for (var w = 0; w < warnings.length; w++) {
                lines.push("[WARN] " + warnings[w]);
            }

            lines.push("");
            lines.push("Next Actions:");
            lines.push("1) Populate all required Online Submission fields.");
            lines.push("2) Ensure soapEndpoint is a valid https URL.");
            lines.push("3) Save settings before running production submissions.");
        }

        return {
            status: status,
            summary: summary,
            details: lines.join("\n"),
        };
    }

    async function runTest(button, panel) {
        state.running = true;
        updateButtonAvailability(button, document.getElementById(WARNING_ID));
        button.textContent = "Testing...";
        setPanelState(
            panel,
            "INFO",
            "Running backend validation against the SOAP endpoint using configured mTLS materials."
        );

        try {
            var url = validationEndpointUrl();
            var response = await fetch(url, {
                method: "GET",
                credentials: "include",
                headers: {
                    Accept: "application/json",
                },
            });

            if (!response.ok) {
                var body = await response.text();
                throw new Error(
                    "HTTP " + response.status + " while calling validation endpoint:\n" +
                    url + "\n\n" + body
                );
            }

            var payload = await response.json();
            var result = extractValidationResponse(payload);
            var message = "[" + result.status + "] " + result.summary;
            if (result.status !== "PASS" && result.details) {
                message += "\n\n" + result.details;
            }
            setPanelState(panel, result.status, message);
        } catch (error) {
            setPanelState(
                panel,
                "FAIL",
                "[FAIL] Unable to run validation endpoint.\n\n" + (error && error.message ? error.message : String(error))
            );
        } finally {
            state.running = false;
            button.textContent = "Test Connection";
            updateButtonAvailability(button, document.getElementById(WARNING_ID));
        }
    }

    function injectButton() {
        var tab = findOnlineSubmissionTab();
        if (!tab || tab.querySelector("#" + BUTTON_ID)) {
            return;
        }

        var anchor = tab.querySelector("form") || tab.querySelector("div") || tab;
        if (!anchor) {
            return;
        }

        var wrapper = document.createElement("div");
        wrapper.style.margin = "8px 0 16px 0";

        var button = document.createElement("button");
        button.id = BUTTON_ID;
        button.type = "button";
        button.textContent = "Test Connection";
        button.style.background = "#0b5cab";
        button.style.color = "#fff";
        button.style.border = "none";
        button.style.borderRadius = "4px";
        button.style.padding = "8px 16px";
        button.style.cursor = "pointer";
        button.style.marginLeft = "8px";

        var warning = document.createElement("div");
        warning.id = WARNING_ID;
        warning.style.marginTop = "8px";
        warning.style.fontSize = "12px";
        warning.style.color = "#8a6d3b";
        warning.style.minHeight = "16px";

        var panel = createStatusPanel();
        button.addEventListener("click", function () {
            runTest(button, panel);
        });

        var saveButton = (function () {
            var candidates = tab.querySelectorAll("button, input[type='submit'], input[type='button']");
            for (var i = 0; i < candidates.length; i++) {
                var candidate = candidates[i];
                var text = String(candidate.textContent || candidate.value || "").trim().toLowerCase();
                if (text === "save" || text === "save changes") {
                    return candidate;
                }
            }
            return null;
        })();

        if (saveButton && saveButton.parentElement) {
            var saveParent = saveButton.parentElement;

            var buttonRow = document.createElement("div");
            buttonRow.style.display = "flex";
            buttonRow.style.alignItems = "center";
            buttonRow.style.gap = "8px";
            buttonRow.style.flexWrap = "wrap";
            saveParent.insertBefore(buttonRow, saveButton);
            buttonRow.appendChild(saveButton);
            buttonRow.appendChild(button);
            button.style.marginLeft = "";

            var autoTestTimer = null;
            saveButton.addEventListener("click", function () {
                if (autoTestTimer) {
                    clearTimeout(autoTestTimer);
                }
                autoTestTimer = setTimeout(function () {
                    if (state.running) {
                        return;
                    }
                    runTest(button, panel);
                }, SAVE_TRIGGER_TEST_DELAY_MS);
            });

            wrapper.appendChild(warning);
            wrapper.appendChild(panel);
            saveParent.insertAdjacentElement("afterend", wrapper);
        } else {
            wrapper.appendChild(button);
            wrapper.appendChild(warning);
            wrapper.appendChild(panel);
            anchor.appendChild(wrapper);
        }

        updateButtonAvailability(button, warning);
    }

    var observer = new MutationObserver(function () {
        injectButton();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["disabled", "aria-disabled", "class"],
    });

    injectButton();
})();
