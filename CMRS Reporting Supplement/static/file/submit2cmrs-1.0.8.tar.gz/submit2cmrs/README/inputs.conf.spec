[submit2cmrs://<name>]
index = (Default: default)
interval = Time interval of the data input, in seconds. (Default: 86400)
python.required = {3.7|3.9|3.13}
* For Python scripts only, selects which Python version to use.
* Set to "3.9" to use the Python 3.9 version.
* Set to "3.13" to use the Python 3.13 version.
* Optional.
* Default: not set
